import { VerificadoPipe } from './verificado.pipe';

describe('VerificadoPipe', () => {
  it('create an instance', () => {
    const pipe = new VerificadoPipe();
    expect(pipe).toBeTruthy();
  });
});
